
package persistences;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.RobotMarte;
import service.Almacenable;

public class Inventario<T extends RobotMarte> implements Almacenable<T>{

    private final List<T> lista = new ArrayList<>();
    
    @Override
    public void agregar(T elemento) {
        lista.add(elemento);
    }

    
    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        for(T elemento : lista){
            if(criterio.test(elemento)){
                lista.remove(elemento);
            }
        }
    }
    
    private List<T> crearCopiaLista(){
        return (new ArrayList<>(lista));
    }

    @Override
    public List<T> obtenerTodos() {
        return crearCopiaLista();
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        for(T elemento : lista){
            if(criterio.test(elemento)){
                return elemento;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
       Collections.sort((List)lista);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        lista.sort(comparador);
    
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        for(T elemento : lista){
            if(criterio.test(elemento)){
                listaFiltrada.add(elemento);
            }
        }
        return listaFiltrada;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        
        List<T> listaTransformada = new ArrayList<>();

    for (T elemento : this.lista) {        
        T nuevo = operador.apply(elemento);
        listaTransformada.add(nuevo);       
        }
    return listaTransformada;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for (T elemento : lista){
            if (criterio.test(elemento)){
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        File archivo = new File(ruta);
        File carpeta = archivo.getParentFile();
         if (!carpeta.exists()) carpeta.mkdirs();
        try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(ruta))) {
            o.writeObject(lista);
        }
    
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        
        try (ObjectInputStream o = new ObjectInputStream(new FileInputStream(ruta))) {
            List<T> cargada = (List<T>) o.readObject();
            lista.clear();
            lista.addAll(cargada);
        }
    
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        File archivo = new File(ruta);
        File carpeta = archivo.getParentFile();
         if (!carpeta.exists()) carpeta.mkdirs();
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : lista) {
                escritor.write(((service.CSVConvertible) elemento).toCSV());
                escritor.newLine();
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    lista.add(fromCSV.apply(linea));
                }
            }
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    
    }

    @Override
     public void guardarEnJSON(String ruta) throws Exception {
        try (FileWriter writer = new FileWriter(ruta)) {

            writer.write("[\n");
            for (int i = 0; i < lista.size(); i++) {
                writer.write(lista.get(i).toJSON());
                if (i < lista.size() - 1) writer.write(",\n");
            }
            writer.write("\n]");
        }
    }
}