
package sistemadegestionderobotsexploradoresdemarte;

import java.util.List;
import model.RobotMarte;
import static model.RobotMarte.fromCSV;
import model.TipoRobot;
import persistences.Inventario;
import service.Almacenable;

public class SistemaDeGestionDeRobotsExploradoresDeMarte {

    public static void main(String[] args) {
        try {
            Almacenable<RobotMarte> inv = new Inventario<>();
            inv.agregar(new RobotMarte(101, "Ares-1", TipoRobot.RECOLECTOR, 85, 2019,
            123.5));
            inv.agregar(new RobotMarte(102, "Vulcan-7", TipoRobot.SENSORIAL, 40, 2020,
            88.2));
            inv.agregar(new RobotMarte(103, "GeoMax", TipoRobot.GEOLOGICO, 25, 2017,
            210.4));
            inv.agregar(new RobotMarte(104, "TopoTrack", TipoRobot.TOPOGRAFICO, 77, 2021,
            156.0));
            inv.agregar(new RobotMarte(105, "HelperX", TipoRobot.ASISTENCIA, 50, 2018,
            95.3));
            inv.agregar(new RobotMarte(106, "Ares-2", TipoRobot.RECOLECTOR, 33, 2016,
            178.9));
            System.out.println("=== Inventario Original ===");
            for (RobotMarte r : inv.obtenerTodos()) {
            System.out.println(r);
            }
            // 1) Orden natural
            inv.ordenar();
            System.out.println("\n=== Orden Natural ===");
            for (RobotMarte r : inv.obtenerTodos()) {
            System.out.println(r);
            }
            // 2) Ordenar por nombre → completar Comparator
            inv.ordenar(/* Comparator por nombre */);
            System.out.println("\n=== Ordenados por Nombre ===");
            for (RobotMarte r : inv.obtenerTodos()) {
            System.out.println(r);
            }
            // 3) Filtrar robots con batería < 30 → completar Predicate
            System.out.println("\n=== Robots con Batería < 30% ===");
            List<RobotMarte> criticos =
            inv.filtrar(p -> p.getNivelBateria() < 30);
            for (RobotMarte r : criticos) {
            System.out.println(r);
            }
            // 4) Transformar RECOLECTOR → +20% km → completar Function
            System.out.println("\n=== Transformación RECOLECTORES ===");
            List<RobotMarte> transformados =
            inv.transformar(d -> {
                if (d.getTipo()== TipoRobot.ASISTENCIA) {
                    d.setKmRecorridos((int)(d.getKmRecorridos()* 1.20));           
                    }
                    return d; 
                        });
            for (RobotMarte r : transformados) {
            System.out.println(r);
            }
            // 5) Contar robots fabricados antes de 2018 → completar Predicate
            int antiguos = inv.contar(p -> p.getAnioFabricacion() < 2018);
            System.out.println("\nRobots fabricados antes de 2018: " + antiguos);
            // Persistencias
            inv.guardarEnBinario("src/data/robots.bin");
            inv.guardarEnCSV("src/data/robots.csv");
            inv.guardarEnJSON("src/data/robots.json");
            // Carga desde CSV
            Almacenable<RobotMarte> invCSV = new Inventario<>();
            invCSV.cargarDesdeCSV("src/data/robots.csv",
                    RobotMarte::fromCSV);
            System.out.println("\n=== Inventario cargado desde CSV ===");
            for (RobotMarte r : invCSV.obtenerTodos()) {
            System.out.println(r);
            }
            } catch (Exception e) {
            System.err.println(e.getMessage());
            }

            }

}
