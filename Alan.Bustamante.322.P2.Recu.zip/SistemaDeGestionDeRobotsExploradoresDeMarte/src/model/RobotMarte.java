
package model;

import service.CSVConvertible;
import service.JSONConvertible;

public class RobotMarte implements Comparable<RobotMarte>, CSVConvertible, JSONConvertible {
    private int id;
    private String nombre;
    private TipoRobot tipo;
    private int nivelBateria;
    private int anioFabricacion;
    private double kmRecorridos;

    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria, int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = nivelBateria;
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    public int getNivelBateria() {
        return nivelBateria;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public double getKmRecorridos() {
        return kmRecorridos;
    }

    @Override
    public String toString() {
        return "RobotMarte{" + "id=" + id + ", nombre=" + nombre + ", tipo=" + tipo + ", nivelBateria=" + nivelBateria + ", anioFabricacion=" + anioFabricacion + ", kmRecorridos=" + kmRecorridos + '}';
    }

    
    private static String toHeaderCSV(){
        return "id,nombre,tipo,nivelBateria,anioFabricacion,kmRecorridos";
    }
    
    public static RobotMarte fromCSV(String linea){
        linea = linea.replace("\n", "");
        String[] pates = linea.split(",");
        return new RobotMarte(Integer.parseInt(pates[0]), pates[1], TipoRobot.valueOf(pates[2]), Integer.parseInt(pates[3]), Integer.parseInt(pates[4]), Double.parseDouble(pates[5]));
    }
    
    
    
    @Override
    public int compareTo(RobotMarte o) {
        int criterio1 = Integer.compare(this.getNivelBateria(), o.nivelBateria);
        if(criterio1 == 0){
            return Double.compare(this.getKmRecorridos(), o.getKmRecorridos());
        }
        return criterio1;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + tipo + "," + nivelBateria + "," + anioFabricacion + "," + kmRecorridos;
    
    }

    public void setNivelBateria(int nivelBateria) {
        this.nivelBateria = nivelBateria;
    }

    public void setKmRecorridos(double kmRecorridos) {
        this.kmRecorridos = kmRecorridos;
    }
    
    
    
    public String toJSON() {
    return "{\n" +
           "  \"id\": " + id + ",\n" +
           "  \"nombre\": \"" + nombre + "\",\n" +
           "  \"tipo\": \"" + tipo + "\",\n" +
           "  \"nivelBateria\": " + nivelBateria + ",\n" +               
           "  \"anioFabricacion\": " + anioFabricacion + ",\n" +          
           "  \"kmRecorridos\": " + kmRecorridos + "\n" +                
           "}";
}
    
    
}


