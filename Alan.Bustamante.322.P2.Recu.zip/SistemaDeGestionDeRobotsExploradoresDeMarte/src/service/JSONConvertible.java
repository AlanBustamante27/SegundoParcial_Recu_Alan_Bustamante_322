
package service;

import java.io.Serializable;

public interface JSONConvertible extends Serializable {
    String toJSON();
}
