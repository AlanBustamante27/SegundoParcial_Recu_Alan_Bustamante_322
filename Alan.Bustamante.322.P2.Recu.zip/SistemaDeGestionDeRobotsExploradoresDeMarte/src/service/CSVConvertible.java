
package service;

import java.io.Serializable;

public interface CSVConvertible extends Serializable {
    String toCSV();
}

